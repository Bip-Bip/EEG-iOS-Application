//
//  XYZThirdViewController.h
//  MindsetEEG
//
//  Created by Quentin Le Corre on 16/05/13.
//  Copyright (c) 2013 Quentin Le Corre. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZThirdViewController : UIViewController

@end
