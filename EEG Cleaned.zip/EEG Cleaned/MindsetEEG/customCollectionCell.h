//
//  customCollectionCell.h
//  MindsetEEG
//
//  Created by Quentin Le Corre on 04/05/13.
//  Copyright (c) 2013 Quentin Le Corre. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customCollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *myLabel;

@end
