//
//  MindsetEEGTests.h
//  MindsetEEGTests
//
//  Created by Quentin Le Corre on 03/05/13.
//  Copyright (c) 2013 Quentin Le Corre. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MindsetEEGTests : SenTestCase

@end
