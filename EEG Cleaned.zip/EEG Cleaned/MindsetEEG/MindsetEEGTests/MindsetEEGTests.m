//
//  MindsetEEGTests.m
//  MindsetEEGTests
//
//  Created by Quentin Le Corre on 03/05/13.
//  Copyright (c) 2013 Quentin Le Corre. All rights reserved.
//

#import "MindsetEEGTests.h"

@implementation MindsetEEGTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MindsetEEGTests");
}

@end
